#!/usr/bin/env python

def hello(who):
	print("Welcome to the {}!".format(who))
def main():
	hello("Brain Games")
if __name__ == "__main__":
	main()
